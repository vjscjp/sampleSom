//>>built
define("dijit/_editor/nls/nb/LinkDialog",({createLinkTitle:"Koblingsegenskaper",insertImageTitle:"Bildeegenskaper",url:"URL:",text:"Beskrivelse:",target:"Mål:",set:"Definer",currentWindow:"Gjeldende vindu",parentWindow:"Overordnet vindu",topWindow:"Øverste vindu",newWindow:"Nytt vindu"}));
