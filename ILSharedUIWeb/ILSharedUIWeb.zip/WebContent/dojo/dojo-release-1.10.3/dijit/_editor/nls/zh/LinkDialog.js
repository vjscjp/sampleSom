//>>built
define("dijit/_editor/nls/zh/LinkDialog",({createLinkTitle:"链接属性",insertImageTitle:"图像属性",url:"URL：",text:"说明：",target:"目标：",set:"集",currentWindow:"当前窗口",parentWindow:"父窗口",topWindow:"最顶层窗口",newWindow:"新建窗口"}));
